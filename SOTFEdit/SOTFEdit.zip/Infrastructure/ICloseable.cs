﻿namespace SOTFEdit.Infrastructure;

public interface ICloseable
{
    public void Close();
}