﻿namespace SOTFEdit.ViewModel;

public enum MapType
{
    Dark,
    Original
}