﻿namespace SOTFEdit.Model.Map;

public static class PoiGroupKeys
{
    public const string Actors = "actors";
    public const string Items = "items";
    public const string Structures = "structures";
    public const string WorldItems = "worlditems";
}