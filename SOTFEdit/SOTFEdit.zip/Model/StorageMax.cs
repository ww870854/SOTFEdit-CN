﻿namespace SOTFEdit.Model;

// ReSharper disable once ClassNeverInstantiated.Global
public record StorageMax(int Inventory, int Shelf, int? Holder);