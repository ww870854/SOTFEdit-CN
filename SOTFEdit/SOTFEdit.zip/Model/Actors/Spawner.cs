﻿namespace SOTFEdit.Model.Actors;

// ReSharper disable once ClassNeverInstantiated.Global
public record Spawner(int UniqueId, int Count, float LastSpawnTime);