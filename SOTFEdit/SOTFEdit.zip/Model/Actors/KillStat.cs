﻿namespace SOTFEdit.Model.Actors;

// ReSharper disable once ClassNeverInstantiated.Global
public record KillStat(int TypeId, int PlayerKilled);