﻿namespace SOTFEdit.Model.Actors;

public enum ActorModificationMode
{
    Remove,
    Modify
}