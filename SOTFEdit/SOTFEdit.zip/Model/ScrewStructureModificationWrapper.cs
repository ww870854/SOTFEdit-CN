﻿namespace SOTFEdit.Model;

public class ScrewStructureModificationWrapper
{
    public ScrewStructureModificationMode? ModificationMode { get; set; }
    public ScrewStructureOrigin Origin { get; set; }
}