﻿namespace SOTFEdit.Model;

public enum ScrewStructureModificationMode
{
    None,
    Remove,
    AlmostFinish,
    Finish,
    Unfinish
}