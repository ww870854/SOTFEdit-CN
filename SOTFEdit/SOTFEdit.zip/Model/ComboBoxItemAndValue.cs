﻿namespace SOTFEdit.Model;

// ReSharper disable once NotAccessedPositionalProperty.Global
public record ComboBoxItemAndValue<T>(string Title, T Value);