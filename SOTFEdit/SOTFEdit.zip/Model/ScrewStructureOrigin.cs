﻿namespace SOTFEdit.Model;

public enum ScrewStructureOrigin
{
    Unfinished,
    Finished
}