﻿namespace SOTFEdit.Model.WorldItem;

public enum WorldItemType
{
    HangGlider,
    KnightV,
    GolfCart,
    Radio,
    Unknown
}