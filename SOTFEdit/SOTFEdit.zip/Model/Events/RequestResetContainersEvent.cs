﻿namespace SOTFEdit.Model.Events;

public class RequestResetContainersEvent
{
}