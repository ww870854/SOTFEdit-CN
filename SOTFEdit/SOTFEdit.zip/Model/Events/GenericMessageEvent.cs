﻿namespace SOTFEdit.Model.Events;

public record GenericMessageEvent(string Message, string Title);