﻿namespace SOTFEdit.Model.Events;

public class RequestModifyConsumedItemsEvent
{
}